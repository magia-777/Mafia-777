+++
title = "Adopters"
+++

## Adopters of the Contributor Covenant

A sample of projects that have adopted the Contributor Covenant:

{{< data-list "static/adopters.csv" >}}

To add your project to the list, [submit a pull
request](https://github.com/ContributorCovenant/contributor_covenant/blob/release/README.md#adding-a-project-to-the-list-of-adopters "Contributor Covenant source code").
