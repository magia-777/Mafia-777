This project is governed by the Contributor Covenant version 1.4
(https://www.contributor-covenant.org/version/1/4/code-of-conduct.html).  
All contributors and participants agree to abide by its terms.  
To report violations, send an email to covenant@idolhands.com.
